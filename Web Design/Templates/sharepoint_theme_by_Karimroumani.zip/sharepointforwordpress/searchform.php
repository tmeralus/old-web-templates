<form role="search" method="get"  action="<?php  echo get_option('home') ;?>" >
	<div>
	<input type="text" value="" name="s"  />
	<input type="submit" value="Search" />
	</div>
</form>