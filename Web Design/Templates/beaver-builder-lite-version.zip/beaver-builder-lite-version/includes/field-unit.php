<input 
type="number"
name="<?php esc_attr_e( $name ); ?>"
value="<?php esc_attr_e( $value ); ?>" 
placeholder="<?php if ( isset( $field['placeholder'] ) ) esc_attr_e( $field['placeholder'] ); ?>"
/>