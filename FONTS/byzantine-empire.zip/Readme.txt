Byzantine Empire Font

The Byzantine Empire font is a sans-serif stencil font created in FontLab Studio and Microsoft Paint. It includes alphanumeric characters, punctuation and international characters. This font is in the public domain. Please read the terms of use at http://jlhfonts.blogspot.com/.